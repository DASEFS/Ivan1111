# Ivan.miller Fashion Magazine v2

This is a responsive English-first / Simplified Chinese fashion-magazine starter with local editorial image assets.

## Update content
Edit `data/articles.json`. Add another article object with `id`, `category`, `date`, `title`, `coverLabel`, `image`, `excerpt`, and `body`. The magazine grid and article page render the content automatically.

## Before launch
- Replace `https://ivan-miller.example/` with your real domain.
- Replace the Google Maps placeholder with your actual office/studio location.
- Connect the enquiry form to a real email/form service.
- Add GA4 / Meta Pixel only after the required cookie consent.
- Replace starter privacy/cookie text with legally reviewed policies.
- Replace demo editorial images with licensed/original photography if publishing commercially.

## Important
This v2 is a polished front-end/content prototype. A true online admin backend requires a CMS or server/database. The content structure is already prepared for that next step.
